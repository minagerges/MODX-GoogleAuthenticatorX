======================
 GoogleAuthenticatorX
======================
Author: Mina Gerges <gerges.mina@gmail.com>

GoogleAuthenticatorX is a ModX extra that integrates Google's 2-step verification to manager login & front end login via pre-hook for "Login" extra.
Users have to use Google Authenticator mobile software to get the authentication key which changes every 30 seconds.

Please see documentation at:
https://github.com/minagerges/MODX-GoogleAuthenticatorX/wiki